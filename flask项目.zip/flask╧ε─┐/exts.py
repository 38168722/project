#!/usr/bin/env python
# -*- coding: utf-8 -*-
from flask_sqlalchemy import SQLAlchemy
from flask项目 import app
db = SQLAlchemy()
# db.create_all()